from django import forms

class Member(forms.Form):
    username = forms.CharField(min_length=1, required=True)
    password = forms.CharField(min_length=8, required=True)