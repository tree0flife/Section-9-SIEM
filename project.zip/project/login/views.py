from django.shortcuts import render
from .forms import Member

def display(request):
    form_class = Member

    return render(request, 'login/login.html', {
        'form': form_class
    })