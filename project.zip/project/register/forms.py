from django import forms

class NewMember(forms.Form):
    first_name = forms.CharField(min_length = 1, required = True)
    last_name = forms.CharField(min_length = 1, required = True)
    email = forms.EmailField(min_length = 1, required = True)
    username = forms.CharField(min_length = 1, required = True)
    password = forms.CharField(min_length = 1, required = True)
    confirm_password = forms.CharField(min_length = 1, required = True)