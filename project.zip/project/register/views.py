from django.shortcuts import render
from .forms import NewMember

def reg_form(request):
    class_form = NewMember

    return render(request, 'register/register.html', {
        'forms': class_form,
    })